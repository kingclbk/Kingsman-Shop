package models;

public class OrderLine {
    // Initialisation of variables for OrderLine class.
    private int orderLineID;
    private String product;
    private int quantity;
    private Product price;
    private double lineTotal;
    private Product productBought;
    
    // Constructor with everything to set default values.
    public OrderLine(){
        orderLineID = 0;
        product = "No name";
        quantity = 0;
        lineTotal = 0.0;
    }
    
    //Constructor with product in and quantity in, because code doesn't work without it
    public OrderLine(Product productIn, int quantityIn) {
        orderLineID = 0; // or generate ID
        productBought = productIn; // store the Product object
        quantity = quantityIn;
        lineTotal = productBought.getPrice() * quantity;
    }

    // Constructor with everything but lineTotal
    public OrderLine(int orderLineIDIn, String productIn, int quantityIn){
        orderLineID = orderLineIDIn;
        product = productIn;
        quantity = quantityIn;
        lineTotal = productBought.getPrice() * quantity;
    }
    
    //OrderLine constructor with just product
    public OrderLine(Product productIn){
        orderLineID = 0;
        productBought = productIn;
        lineTotal = productBought.getPrice();
    }
    
    // Getters
    public int getOrderLineID(){return orderLineID;}
    public String getProduct(){return product;}
    public int getQuantity(){return quantity;}
    public double getLineTotal(){return lineTotal;}
    public Product getPrice(){return price;}
    public Product getProductBought(){return productBought;}
    
    // Setters
    public void setOrderLineID(int orderLineIDIn){orderLineID = orderLineIDIn;}
    public void setProduct(String productIn){product = productIn;}
    public void setQuantity(int quantityIn){quantity = quantityIn;}
    public void setLineTotal(double lineTotalIn){lineTotal = lineTotalIn;}
    public void setProductBought(Product productBoughtIn){productBought = productBoughtIn;}
}
